clear all;
close all;

%%%% openFieldV4.m user input box width is in CM not inches 07.08.21
num_files =1;
boxWidth = 25.5;
playMovie = 0;
excelFilename = 'your_file_name.xlsx';
%%%%%%%%%%%%


for j = 1:num_files
    [avifilename, avipath] = uigetfile('*.avi','pick your file');
    eval(['fullfilename' num2str(j) ' = [avipath avifilename]']);
    filename{j} = avifilename;
end


for kk = 1:num_files
    eval(['fullfilename=fullfilename' num2str(kk)]);
    vidObj = VideoReader(fullfilename);
    
    k = 1;
    while k < 3
        sampleFrame = readFrame(vidObj);
        k = k+1;
    end
    
    figure('units','normalized','outerposition',[0 0 1 1]);
    image(sampleFrame); axis image;
    a = text(100, 75, 'Pick cage 1 boundary', 'Color', 'b');
    h = impoly;
    border(kk).cage1 = getPosition(h);
    delete(a);
    
    a = text(100, 75, 'Pick cage 2 boundary', 'Color', 'r');
    h = impoly;
    border(kk).cage2 = getPosition(h);
    delete(a);
    
    a = text(100, 75, 'Pick two points between the cages', 'Color', 'g');
    [x,y] = ginput(2);
    boundX(kk) = mean(x);
    delete(a);
    close all;
end

for kk = 1:num_files
    clear mov;
    clear data;
    eval(['fullfilename=fullfilename' num2str(kk)]);
    vidObj = VideoReader(fullfilename);
    
    %%%%% load movie
    k = 1;
    h = waitbar(0,['Loading movie ' num2str(kk) ' of ' num2str(num_files)]);
    while hasFrame(vidObj)
        temp = readFrame(vidObj);
%         temp = [temp(:,432:end,:) temp(:,1:431,:)];
        mov(k).cdata = temp(:,:,1);
        k = k+1;
        waitbar(k/(vidObj.Duration*vidObj.FrameRate))
    end
    close(h)
    clear('vidObj');
    
    temp = zeros(size(mov(1).cdata));
    for n = 1:length(mov)
        temp = temp + double(mov(n).cdata);
    end
    avgFrame = uint8(temp/length(mov));
    
    for n = 1:length(mov)
        mov(n).diff = imabsdiff(mov(n).cdata,avgFrame);
    end
    if playMovie == 0
        mov = rmfield(mov,'cdata');
    end
    
    diffWin = 300;
    for n = diffWin+1:length(mov)
        mov(n).diff2 = imsubtract(mov(n).diff, mov(n-diffWin).diff);
    end
    mov = mov(diffWin+1:length(mov));
    mov = rmfield(mov,'diff');
    
    for n = 1:length(mov)
        mov(n).diff3 = (mov(n).diff2 - mean2(mov(n).diff2)) / std2(mov(n).diff2);
    end
    mov = rmfield(mov,'diff2');
    
    %%%%%% find features
%     bw = im2bw(avgFrame,0.7);
%     bw2 = bwlabel(bw);
%     x = regionprops(bw2,'Area','BoundingBox','Centroid');
%     xVals = [];
%     for i = 1:length(x)
%         xVals(i) = x(i).Area;
%     end
%     [xVals, ind] = sort(xVals);
%     if x(ind(end)).Centroid(1) < x(ind(end-1)).Centroid(1)
%         boundX = mean([x(ind(end)).BoundingBox(1)+x(ind(end)).BoundingBox(3) x(ind(end-1)).BoundingBox(1)]);
%     else
%         boundX = mean([x(ind(end-1)).BoundingBox(1)+x(ind(end-1)).BoundingBox(3) x(ind(end)).BoundingBox(1)]);
%     end
    
    
    %%%% track mouse
    stdThresh = 4;
    minSigPix = 4;
    hh = waitbar(0,['Tracking mouse in movie ' num2str(kk) ' of ' num2str(num_files)]);
    mLocL = zeros(length(mov),2);
    mLocR = zeros(length(mov),2);
    for n = 1:length(mov)
        temp1 = mov(n).diff3;
        temp1(:,round(boundX(kk)):end) = 0;
        temp1(temp1 < stdThresh) = 0;
        temp1(temp1 >= stdThresh) = 1;
        
        temp2 = mov(n).diff3;
        temp2(:,1:round(boundX(kk))) = 0;
        temp2(temp2 < stdThresh) = 0;
        temp2(temp2 >= stdThresh) = 1;
        
        x = regionprops(temp1,'Centroid');
        if n == 1
            mLocL(n,:) = [0,0];
        else
            if length(find(temp1 == 1)) >= minSigPix
                mLocL(n,:) = [x.Centroid(1),x.Centroid(2)];
            else
                mLocL(n,:) = mLocL(n-1,:);
            end
        end
        
        x = regionprops(temp2,'Centroid');
        if n == 1
            mLocR(n,:) = [0,0];
        else
            if length(find(temp2 == 1)) >= minSigPix
                mLocR(n,:) = [x.Centroid(1),x.Centroid(2)];
            else
                mLocR(n,:) = mLocR(n-1,:);
            end
        end
        waitbar(n/length(mov))
    end
    close(hh)
    
    data.cage1Loc = mLocL;
    data.cage2Loc = mLocR;
    
    
    %%%% calculate scale factor
    xVals = border(kk).cage1(:,1);
    xVals = sort(xVals);
    data.cage1XScale = boxWidth / abs(mean(xVals(1:2))-mean(xVals(end-1:end)));
    yVals = border(kk).cage1(:,2);
    yVals = sort(yVals);
    data.cage1YScale = boxWidth / abs(mean(yVals(1:2))-mean(yVals(end-1:end)));
    
    xVals = border(kk).cage2(:,1);
    xVals = sort(xVals);
    data.cage2XScale = boxWidth / abs(mean(xVals(1:2))-mean(xVals(end-1:end)));
    yVals = border(kk).cage2(:,2);
    yVals = sort(yVals);
    data.cage2YScale = boxWidth / abs(mean(yVals(1:2))-mean(yVals(end-1:end)));
    
    %%%%% calculate distance traveled
    maxDistJump = 5;
    dist1 = zeros(size(data.cage1Loc,1),1);
    temp1 = data.cage1Loc;
    temp1(:,1) = smooth(temp1(:,1),10);
    temp1(:,2) = smooth(temp1(:,2),10);
    for n = 1:size(data.cage1Loc,1)-1
        dx = temp1(n+1,1) - temp1(n,1);
        dy = temp1(n+1,2) - temp1(n,2);
        tempDist = sqrt((dx*data.cage1XScale)^2 + (dy*data.cage1YScale)^2);
        if tempDist < maxDistJump
            dist1(n) = tempDist;
        end
    end
    data.cage1DistJump = dist1;
    data.cage1DistTrav = sum(data.cage1DistJump);
    
    dist2 = zeros(size(data.cage2Loc,1),1);
    temp1 = data.cage2Loc;
    temp1(:,1) = smooth(temp1(:,1),10);
    temp1(:,2) = smooth(temp1(:,2),10);
    for n = 1:size(data.cage2Loc,1)-1
        dx = temp1(n+1,1) - temp1(n,1);
        dy = temp1(n+1,2) - temp1(n,2);
        tempDist = sqrt((dx*data.cage2XScale)^2 + (dy*data.cage2YScale)^2);
        if tempDist < maxDistJump
            dist2(n) = tempDist;
        end
    end
    data.cage2DistJump = dist2;
    data.cage2DistTrav = sum(data.cage2DistJump);
    
    %%%% calculate distance to border
    dist1 = zeros(size(data.cage1Loc,1),1);
    for n = 1:size(data.cage1Loc,1)
        [a,b,c] = p_poly_dist(data.cage1Loc(n,1),data.cage1Loc(n,2),border(kk).cage1(:,1),border(kk).cage1(:,2));
        dx = b - data.cage1Loc(n,1);
        dy = c - data.cage1Loc(n,2);
        dist1(n) = sqrt((dx*data.cage1XScale)^2 + (dy*data.cage1YScale)^2);
    end
    
    dist2 = zeros(size(data.cage2Loc,1),1);
    for n = 1:size(data.cage2Loc,1)
        [a,b,c] = p_poly_dist(data.cage2Loc(n,1),data.cage2Loc(n,2),border(kk).cage2(:,1),border(kk).cage2(:,2));
        dx = b - data.cage2Loc(n,1);
        dy = c - data.cage2Loc(n,2);
        dist2(n) = sqrt((dx*data.cage2XScale)^2 + (dy*data.cage2YScale)^2);
    end
    
    data.cage1Dist = dist1;
    data.cage2Dist = dist2;
    
    %%% bin distances
    int = 1:21;
    data.cage1DistInt = zeros(length(int),1);
    data.cage2DistInt = zeros(length(int),1);
    for n = 1:length(int)
        if n == 1
            data.cage1DistInt(n) = length(find(data.cage1Dist < int(n)))/length(data.cage1Dist);
            data.cage2DistInt(n) = length(find(data.cage2Dist < int(n)))/length(data.cage2Dist);
        elseif n > 1 && n < 21
            data.cage1DistInt(n) = length(find(data.cage1Dist >= int(n-1) & data.cage1Dist < int(n)))/length(data.cage1Dist);
            data.cage2DistInt(n) = length(find(data.cage2Dist >= int(n-1) & data.cage2Dist < int(n)))/length(data.cage2Dist);
        else
            data.cage1DistInt(n) = length(find(data.cage1Dist > int(n-1)))/length(data.cage1Dist);
            data.cage2DistInt(n) = length(find(data.cage2Dist > int(n-1)))/length(data.cage2Dist);
        end
    end
    
    save(strcat(fullfilename(1:end-4), '.mat'),'data','border');
    
    if kk == 1
        xlswrite(excelFilename,{'File'},1,'A2');
        xlswrite(excelFilename,{'Cage'},1,'B2');
        xlswrite(excelFilename,{'Dist Trav'},1,'C2');
        
        for i = 1:21
            if i == 1
                xlswrite(excelFilename,{'< 1 cm'},1,strcat(char(64+i+4),'2'));
            elseif i > 1 && i < 21
                xlswrite(excelFilename,{[num2str(i-1) '-' num2str(i) ' cm']},1,strcat(char(64+i+4),'2'));
            else
                xlswrite(excelFilename,{'> 20 cm'},1,strcat(char(64+i+4),'2'));
            end
        end
        for i = 1:21
            if i < 21
                xlswrite(excelFilename,{['< ' num2str(i) ' cm']},1,strcat(char(65),char(64+i),'2'));
            else
                xlswrite(excelFilename,{'all'},1,strcat(char(65),char(64+i),'2'));
            end
        end
                
        hExcel = actxserver('Excel.Application');
        hWorkbook = hExcel.Workbooks.Open(strcat(avipath,excelFilename));
        hWorksheet = hWorkbook.Sheets.Item(1);
        hWorksheet.Range('A1:ZZ100').NumberFormat = '0.00';
        hWorksheet.Columns.Item(1).columnWidth = 50;
        for n = 2:100
            hWorksheet.Columns.Item(n).columnWidth = 10;
        end
        
        hWorkbook.Save
        hWorkbook.Close
        hExcel.Quit
    end
    
    xlswrite(excelFilename,filename(kk),1,strcat('A',num2str(kk*3)));
    xlswrite(excelFilename,1,1,strcat('B',num2str(kk*3)));
    xlswrite(excelFilename,2,1,strcat('B',num2str(kk*3+1)));
    xlswrite(excelFilename,data.cage1DistTrav,1,strcat('C',num2str(kk*3)));
    xlswrite(excelFilename,data.cage2DistTrav,1,strcat('C',num2str(kk*3+1)));
    
    for i = 1:21
        xlswrite(excelFilename,data.cage1DistInt(i),1,strcat(char(64+i+4),num2str(kk*3)));
        xlswrite(excelFilename,data.cage2DistInt(i),1,strcat(char(64+i+4),num2str(kk*3+1)));
    end
        
    for i = 1:21
        xlswrite(excelFilename,sum(data.cage1DistInt(1:i)),1,strcat(char(65),char(64+i),num2str(kk*3)));
        xlswrite(excelFilename,sum(data.cage2DistInt(1:i)),1,strcat(char(65),char(64+i),num2str(kk*3+1)));
    end
            
end

if playMovie == 1
    figure('units','normalized','outerposition',[0 0 1 1]); hold on; axis image;
    for n = 1:length(mov)
        frame = mov(n).cdata;
        frame = cat(3,frame,frame);
        frame = cat(3,frame,mov(n).cdata);
        image(frame);
        text(100,300,num2str(n),'color','k')
        
        plot(data.cage1Loc(n,1),data.cage1Loc(n,2),'ro')
        plot(data.cage2Loc(n,1),data.cage2Loc(n,2),'ro')
        
        text(100,100,num2str(data.cage1Dist(n)),'color','r');
        text(500,100,num2str(data.cage2Dist(n)),'color','r');
        
        text(100,200,num2str(data.cage1DistJump(n)),'color','r');
        text(500,200,num2str(data.cage2DistJump(n)),'color','r');
        
        if mod(n,500) == 0
            pause(10);
        else
            pause(1/120);
        end
        cla;
    end
end




